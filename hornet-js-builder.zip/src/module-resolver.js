
var Module = require("module").Module;
var path = require("path");
var Helper = require("./helpers");
var fs = require("fs");

var moduleDirectories = [];

if (!Module._old_nodeModulePaths) {
    Module._old_nodeModulePaths = Module._nodeModulePaths;
    Module._nodeModulePaths = function (from) {
        let paths = [];
        // ajouter au fur et à mesure suivant les besoins des taches
        moduleDirectories.forEach(function (moduleDirectory) {
            paths.push(moduleDirectory);
        });
        paths = Module._old_nodeModulePaths.call(this, from);
        paths.push(process.cwd());
        paths.push(path.join(process.cwd(), ".."));
        return paths;
    };
}

if (!Module._old_resolveLookupPaths) {
    Module._old_resolveLookupPaths = Module._resolveLookupPaths;
    Module._resolveLookupPaths = function(request, parent, newReturn) {
        let resolveLookupPaths = Module._old_resolveLookupPaths.call(this, request, parent, newReturn);
        
        // Check for relative path
        if (request.indexOf('.') == -1 ) {

            // ajouter au fur et à mesure suivant les besoins des taches
            moduleDirectories.forEach(function (moduleDirectory) {
                if(resolveLookupPaths && Array.isArray(resolveLookupPaths)) {
                    if(Array.isArray(resolveLookupPaths[1])) {
                        resolveLookupPaths[1].splice(0, 0, moduleDirectory);
                    } else {
                        resolveLookupPaths.splice(0, 0, moduleDirectory);
                    }
                }
            });
        }
        return resolveLookupPaths;
    };
}

function addModuleDirectory(path2add) {
    var parent;
    path2add = path.normalize(path2add);
    var current = process.cwd();
    if (moduleDirectories.indexOf(path2add) === -1) {
        var path2addBuilder = path.join(path2add, Helper.BUILDER_FILE);
        if (fs.existsSync(path2addBuilder)) {
            var path2addBuilderJS = Helper.ReadTypeBuilderJS(path2addBuilder);
            if (path2addBuilderJS !== Helper.TYPE.APPLICATION && path2addBuilderJS !== Helper.TYPE.APPLICATION_SERVER ||  ((path2addBuilderJS === Helper.TYPE.APPLICATION || path2addBuilderJS === Helper.TYPE.APPLICATION_SERVER) && current === path2add )) {
                moduleDirectories.push(path2add);
                require.main.paths.unshift(path2add);
                parent = module.parent;
                if (parent && parent !== require.main) {
                    parent.paths.unshift(path2add);
                }
            }
        }else{
            moduleDirectories.push(path2add);
            require.main.paths.unshift(path2add);
            parent = module.parent;
            if (parent && parent !== require.main) {
                parent.paths.unshift(path2add);
            }

        }
    }
}

function removeModuleDirectory(path2remove) {
    var idx = moduleDirectories.indexOf(path2remove);
    if (idx != -1) {
        moduleDirectories.splice(idx, 1);
    }
}

function getModuleDirectories() {
    return moduleDirectories.slice(0);
}

function setModuleDirectories(paths) {
    moduleDirectories = paths.slice(0);
}

exports.addModuleDirectory = addModuleDirectory;
exports.removeModuleDirectory = removeModuleDirectory;
exports.getModuleDirectories = getModuleDirectories;
exports.setModuleDirectories = setModuleDirectories;