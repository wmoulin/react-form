"use strict";

const path = require("path");
const mocha = require("gulp-mocha");
var istanbul = require("gulp-istanbul");
const through2 = require('through2');

var Task = require("./../task");

class RunTestMocha extends Task {

    task(gulp, helper, conf, project) {
        return (done) => {
            var hasTestFile = false;
            if (helper.isSkipTests()) {
                helper.info("Exécution des tests annulée car l'option '--skipTests' a été utilisée");
                return done();
            }

            // Transpileur jsx -> js pour les jsx dans les dépendances
            require("node-jsx").install({
                extension: ".jsx",
                harmony: true
            });
            return helper.stream(
                done,
                gulp.src( helper.getFile() ? path.join(conf.testWorkDir, helper.getFile().replace(/\.tsx?$/, ".js")) : conf.testSources, {
                    read: true,
                    base: conf.testSourcesBase
                })
                // Exécution des tests si fichiers sinon mocha plante
                .pipe(through2.obj(function (chunk, encoding, callback) { hasTestFile = true; this.push(chunk); callback();}, function (cb) {
                    !hasTestFile ? helper.info("Aucun test mocha trouvé") & done() : cb();
                  }))
                .pipe(mocha(conf.mocha))
                .on("error", (err) => {
                    helper.error(err);
                    if(helper.getStopOnError()) {
                        process.exit(1);
                    }
                })
                .on("end", () => {
                    // revert modules paths
                    // au cas où un test défini la variable document permet d'éviter que le chargement de 'sinon' échoue
                    delete global.document;
                })
                // Ecriture des rapports de couverture de code
                .pipe(istanbul.writeReports(conf.istanbul))
            );
        }
    }
}


module.exports = RunTestMocha;
